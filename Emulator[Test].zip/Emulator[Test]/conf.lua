﻿function love.conf(t)
    t.version = "11.0"  
    t.window.title = "Emulator"
    t.window.icon = "Icon.PNG" 
end